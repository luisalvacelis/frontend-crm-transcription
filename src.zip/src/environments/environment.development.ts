
export const environment = {
  url_api_main: 'http://127.0.0.1:3000/api/v1/'
};
