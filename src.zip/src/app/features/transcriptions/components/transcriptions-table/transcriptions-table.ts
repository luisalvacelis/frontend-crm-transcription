import { DatePipe } from '@angular/common';
import { Component, DestroyRef, effect, inject, Signal, signal, ViewChild, WritableSignal } from '@angular/core';
import { TranscriptionsStore } from '../../state/transcriptions.store';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';
import { Campaign, CampaignStats } from '../../../../domain/models/campaign.model';
import { PageMeta } from '../../../../domain/models/page.model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { UploadAudios } from "../upload-audios/upload-audios";
import { TranscribeAudios } from '../transcribe-audios/transcribe-audios';

@Component({
  selector: 'app-transcriptions-table',
  imports: [DatePipe, UploadAudios, TranscribeAudios],
  templateUrl: './transcriptions-table.html',
})
export class TranscriptionsTable {

  @ViewChild(UploadAudios) newAudiosTranscriptionModal!: UploadAudios;
  @ViewChild(TranscribeAudios) newTranscribeAudiosModal!: TranscribeAudios;
  // @ViewChild(EditCampaign) editCampaignModal!: EditCampaign;
  // @ViewChild(DeleteCampaign) deleteCampaignModal!: DeleteCampaign;

  private readonly _store: TranscriptionsStore = inject(TranscriptionsStore);
  private readonly _destroyRef: DestroyRef = inject(DestroyRef);
  private readonly _searchSubject: Subject<string> = new Subject<string>();

  public readonly page: WritableSignal<number> = signal<number>(1);
  public readonly pageSize: WritableSignal<number> = signal<number>(10);
  public readonly searchTerm: WritableSignal<string> = signal<string>('');

  public readonly campaignsStats: Signal<CampaignStats[]> = this._store.campaignsStats;
  public readonly meta: Signal<PageMeta | null> = this._store.meta;
  public readonly loading: Signal<boolean> = this._store.loading;
  public readonly error: Signal<string | null> = this._store.error;

  constructor(){
    effect((onCleanup) => {
      const p = this.page();
      const ps = this.pageSize();
      const search = this.searchTerm();

      const sub = this._store
        .load(p, ps, search)
        .pipe(takeUntilDestroyed(this._destroyRef))
        .subscribe();

      onCleanup(() => sub.unsubscribe());

      this._searchSubject
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntilDestroyed(this._destroyRef)
      )
      .subscribe((term) => {
        this.searchTerm.set(term);
        this.page.set(1);
      });
    });
  }

  public onSearchChange(term: string): void{
    this._searchSubject.next(term);
  }

  public clearSearch(): void{
    this.searchTerm.set('');
    this.page.set(1);
  }

  public nextPage(): void{
    const m = this.meta();
    if(!m) return;
    if(this.page() < m._pages) this.page.set(this.page() + 1);
  }

  public prevPage(): void{
    if(this.page() > 1) this.page.set(this.page() - 1);
  }

  public setPageSize(pageSize: number): void{
    this.pageSize.set(pageSize);
    this.page.set(1);
  }

  public newAudios(): void{
    this.newAudiosTranscriptionModal.open();
  }

  public transcribeAudios(campaignStats: CampaignStats): void{
    this.newTranscribeAudiosModal.open(campaignStats)
  }

  // public editCampaign(campaign: Campaign): void {
  //   this.editCampaignModal.open(campaign);
  // }

  // public deleteCampaign(campaign: Campaign): void{
  //   this.deleteCampaignModal.open(campaign);
  // }
}
